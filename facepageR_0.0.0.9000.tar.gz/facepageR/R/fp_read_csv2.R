# Function to read a CSV file
#' @import tidyverse
#' @param
#' @keywords
#' @examples
#' @export
fp_read_csv2 <- function(filename) {
  read_csv2(filename,na="None")
}
